import numpy as np
import util

def loadTextData(filename):
    wfreq = util.Counter()
    h = open(filename, 'r')
    D = []
    for l in h.readlines():
        a = l.split()
        if len(a) > 1:
            y = float(a[0])
            if y > 0.5: y = 1.
            else: y = -1.
            x = {}
            for w in a[1:]:
                x[w] = 1.
            for w in x.keys():
                wfreq[w] += 1
            D.append( (x,y) )
    h.close()

    wid = {}
    widr = []
    maxId = 1
    for w,c in wfreq.items():
        if c >= 100 and c < 0.7*len(D):
            wid[w] = maxId
            widr.append(w)
            maxId += 1

    N = len(D)

    Xall = np.zeros((N,maxId-1), dtype=float)
    Yall = np.zeros((N,), dtype=float)
    for n in range(len(D)):
        (x,y) = D[n]
        Yall[n] = y
        for w in x.keys():
            #if wid.has_key(w):
            if w in wid:
                Xall[n,wid[w]-1] = 1.

    return Xall,Yall,widr

def loadTextDataMC(filename, illegalWords={}):
    wfreq = util.Counter()
    h = open(filename, 'r')
    D = []
    for l in h.readlines():
        a = l.split()
        if len(a) > 1:
            y = int(a[0])
            x = {}
            for w in a[1:]:
                if not w in illegalWords:
                    x[w] = 1.
            for w in x:
                wfreq[w] += 1
            D.append( (x,y) )
    h.close()

    wid = {}
    widr = []
    maxId = 1
    for w,c in wfreq.items():
        if c >= 20 and c < 0.7*len(D):
            wid[w] = maxId
            widr.append(w)
            maxId += 1

    N = len(D)

    Xall = np.zeros((N,maxId-1), dtype=float)
    Yall = np.zeros((N,), dtype=int)
    for n in range(len(D)):
        (x,y) = D[n]
        Yall[n] = y
        for w in x:
            if w in wid:
                Xall[n,wid[w]-1] = 1.

    return Xall,Yall,widr

class NewsData:
    labels = ['WOMEN''S RIGHTS', 'WEATHER', 'SCIENCE & TECHNOLOGY', 'SPORTS', 'BUSINESS & ECONOMY']

    illegalWords = {'women': 1, 'rights': 1, 'weather': 1, 'science': 1, 'technology': 1, 'sports': 1, 'business': 1, 'economy': 1}
    
    Xall,Yall,words = loadTextDataMC('newsdataset.txt', illegalWords)
    N,D = Xall.shape
    N0 = int(float(N) * 0.5)
    X = Xall[0:N0,:]
    Y = Yall[0:N0]
    Xte = Xall[N0:,:]
    Yte = Yall[N0:]

class NewsDataBinary:
    labels = NewsData.labels[0:2]
    X      = NewsData.X[NewsData.Y < 2, :]
    Y      = 2 * (NewsData.Y[NewsData.Y < 2] == 0) - 1
    Xte    = NewsData.Xte[NewsData.Yte < 2, :]
    Yte    = 2 * (NewsData.Yte[NewsData.Yte < 2] == 0) - 1
    words  = NewsData.words
    
def tokenize(s): 
    return np.re.sub('([^A-Za-z0-9 ]+)', ' \\1 ', s).split()  # add space around anything not alphanum
