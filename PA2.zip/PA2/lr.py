﻿"""
In lr.py, we will implement the Logistic Regression (LR) 
for binary classification.
"""

import numpy as np

class lr():
    """
    This class defines the LR implementation of a binary
    classifier.
    """

    def __init__(self):
        """
        Initialize our internal state.
        We probably need to keep track of a weight vector and a bias.
        """
        self.reset()

    def reset(self):
        """
        Reset the internal state of the classifier.
        """
        self.weights = 0   # our weight vector
        self.bias    = 0   # our bias
        self.N = 0         # N: number of examples (rows)
        self.D = 0         # D: number of features (columns)

    def __repr__(self):
        """
        Return a string representation of the model
        """
        return "w=" + repr(self.weights) + ", b=" + repr(self.bias)

    def sigmoid(self,z):
        """
        The logistic function in linear regression is a sigmoid function,
        Sigmoid is a mathematical function that takes any real number and 
        maps it to a probability between 1 and 0.
        """
        return 1.0/(1.0 + np.exp(-z))

    def predict(self, X):
        """
        X is a vector that we're supposed to make a prediction about.
        a return value <0.5 means class -1 and a return value >=0.5 means class +1
        (The product is the linear combination of feature vector X 
         and the current weights vector)
        """
        Y_prediction = np.zeros((1, self.N))
        self.weights = self.weights.reshape(self.D, 1)
        
        z = np.dot(self.weights.T, X) + self.bias
        A = self.sigmoid(z)
        
        for i in range(A):
            if i > 0.5:
                Y_prediction[i] = 1
            else: 
                Y_prediction[i] = 0
        
        return Y_prediction
        # return np.round(self.__sigmoid((X @ self.weights[1:]) + self.bias))
        # 1 if self.sigmoid(z) > 0.5 else -1

    def propagate(self, X, Y):
        """
        loss function derivative
        This function creates the gradient component for each weight value and bias
        loss function derivative for one example is
        ∂L/∂w=X(Yhat−y)
        ∂L/∂b=(Yhat−y)
        """
        z = np.dot(self.weights.T, X)+self.bias 
        A = self.sigmoid(z)                                    
        loss = (-np.sum(Y*np.log(A)+(1-Y)*np.log(1-A)))/self.N
        loss = np.squeeze(loss)
        
        dw = (np.dot(X,(A-Y).T))/self.N
        db = np.average(A-Y) 

        return dw, db, loss
    
    def train(self, X, Y, numEpoch, lRate, option):
        """
        X is a matrix of data points, Y is a vector of +1/0 classes.
        """
        #self.theta = np.zeros(X.shape[1] + 1)
        #X = np.concatenate((np.ones((X.shape[0], 1)), X), axis=1)
        # get the size of the data set
        self.N,self.D = X.shape
        # initialize parameters
        self.weights, self.bias, losses = self.load()
        losses = []    
        for i in range(numEpoch):
            dw,db,loss = self.propagate(X, Y)
            if option == 'L2-norm':
                """
                λ is a hyper-parameter value. We have to find it using cross-validation.
                Larger value λ of will make wᵢ shrink closer to 0, which might lead to underfitting.
                λ = 0, will have no regulariztion effect.
                """
                C = 0.1
                dw = dw * C + np.sum(self.weights)
                db = db * C
            
            # Record and Print the loss every 100 training iterations
            if i % 100 == 0:
                losses.append(loss)
                print ("loss after iteration %i: %f" %(i, loss))

            if np.all(abs(dw) >= self.tolerance):
                # update w and b
                # w=w−α(∂L/∂w) and b=b−α(∂L/∂b)
                self.weights -=  lRate*dw
                self.bias -= lRate*db
            else:
                break

        self.save(self.weights,self.bias,losses)

    def getRepresentation(self):
        """
        Return a tuple of the form (number-of-updates, weights, bias)
        """
        return (self.weights, self.bias)

    def save(self,weights,bias,losses):
        f = open("trainedModel.txt", "w")
        f.write(weights,'\n',bias,'\n',losses)
        f.close()

    def initialize_with_zeros(self,dim):
        w = np.zeros((dim, 1))
        b = 0
        return w, b
    
    def load(self,):
        f = open("trainedModel.txt", "r")
        if f.readline() == '':
            weights,bias = self.initialize_with_zeros(int(self.N))
            return weights,bias,0
        else:
            lines = f.readline()
            # return weights,bias,losses
            return lines[0],lines[1],lines[3]
