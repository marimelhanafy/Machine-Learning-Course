"""
In multiclass.py, we will implement the AVA approach.
"""

import numpy as np
import lr

class multiclass():
    def __init__(self, K):
        self.f = []
        self.K = K
        for i in range(K):
            self.f.append([])
        for j in range(K):
            for i in range(j):
                self.f[j].append(lr())

    def train(self, X, Y):
        for i in range(self.K):
            for j in range(i):
                print('training classifier for', i, 'versus', j)
                Xij =  X[ Y==i | Y==j, : ]
                Yij = (Y[ Y==i | Y==j ] == j) * 2 - 1 # +1 if it's j, -1 if it's i
                lRate = 0.5
                iterations = 1000
                self.f[i][j].train(Xij, Yij,iterations,lRate)

    def predict(self, X):
        vote = np.zeros((self.K,))
        for i in range(self.K):
            for j in range(i):
                p = self.f[i][j].predict(X)
                vote[j] += p
                vote[i] -= p
        return np.argmax(vote)

    def predictAll(self, X):
        N,D = X.shape
        Y   = np.zeros((N,), dtype=int)
        for n in range(N):
            Y[n] = self.predict(X[n,:])
        return Y


